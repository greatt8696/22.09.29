import React from "react";

const Report = () => {
  return (
    <div className=" bg-slate-500 rounded-2xl p-3">
      <h1>Report 컴포넌트</h1>
    </div>
  );
};

export default Report;
